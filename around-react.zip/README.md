# Projects 10: Around The U.S.

### Around The U.S. at Yandex Practicum

* Intro
* Technologies
* Links

**Intro**

* This is a project about explorers, who researched the US. Responsive and JS used, includes form validation. A part of course at Yandex Practicum

**Technologies**

* CSS3
* HTML5
* JavaScript
* BEM
* OOP
* Webpack
* React

**Links**

* [Link to project](https://akkavin.github.io/web_project_4/index.html)

